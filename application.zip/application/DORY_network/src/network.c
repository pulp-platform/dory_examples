/*
 * network.c
 * Alessio Burrello <alessio.burrello@unibo.it>
 * Thorir Mar Ingolfsson <thoriri@iis.ee.ethz.ch>
 *
 * Copyright (C) 2019-2020 University of Bologna
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */
#include "mem_controller.h"
#include "network.h"
#include "dory.h"
#include "layerMaxPool1.h"
#include "layerGemm8_last.h"
#include "layerConvBNRelu6.h"
#include "layerConvBNRelu4.h"
#include "layerConvBNRelu2.h"
#include "layerConvBNRelu5.h"
#include "layerConvBNRelu0.h"
#include "layerConvBNRelu7.h"
#include "layerConvBNRelu3.h"
#include "snrt.h"
#include "printf.h"
#include "data.h"

#define VERBOSE 1


// allocation of buffers with parameters needed by the network execution
const float * Weights_tensors[] = {
  ConvBNRelu0_weights, ConvBNRelu2_weights, ConvBNRelu3_weights, ConvBNRelu4_weights, ConvBNRelu5_weights, ConvBNRelu6_weights, ConvBNRelu7_weights, Gemm8_weights
};

layer layer_i;
__attribute__((section(".data"))) int layers_pointers[9];
__attribute__((section(".data"))) char * Layers_name[9] = {"ConvBNRelu", "MaxPool", "ConvBNRelu", "ConvBNRelu", "ConvBNRelu", "ConvBNRelu", "ConvBNRelu", "ConvBNRelu", "Gemm"};
__attribute__((section(".data"))) int L3_layers[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int L3_input_layers[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int L3_output_layers[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int L3_weights_layers[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int allocate_layer[9] = {1, 0, 1, 1, 1, 1, 1, 1, 1};
__attribute__((section(".data"))) int branch_input[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int branch_output[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int branch_change[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int branch_last[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int check_weights[9] = {770981227, 0, 226561640, 1515711941, 2573863004, 6078588210, -8855463671, 7498956843, 1637};
__attribute__((section(".data"))) int check_weights_dimension[9] = {1216, 0, 9472, 9472, 18944, 37376, 74752, 148480, 7684};
__attribute__((section(".data"))) int cumulative_weights_dimension[9] = {0, 1216, 1216, 10688, 20160, 39104, 76480, 151232, 299712};
__attribute__((section(".data"))) int check_activations[9] = {2818623, 121590, 45486, 14230, 15057, 10668, 15843, 3084, 17906};
__attribute__((section(".data"))) int check_activations_dimension[9] = {15360, 122880, 30720, 7680, 7680, 3840, 3840, 1920, 1920};
__attribute__((section(".data"))) int check_activations_dimension_L3_in[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int check_activations_dimension_L3_out[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int out_mult_vector[9] = {1, 1, 1, 1, 1, 1, 1, 1, 1};
__attribute__((section(".data"))) int out_shift_vector[9] = {24, 1, 23, 23, 23, 23, 24, 21, 1};
__attribute__((section(".data"))) int inmul1_vector[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int inmul2_vector[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
__attribute__((section(".data"))) int check_activations_out[9] = {121590, 45486, 14230, 15057, 10668, 15843, 3084, 17906, -4698};
__attribute__((section(".data"))) int check_activations_out_dimension[9] = {122880, 30720, 7680, 7680, 3840, 3840, 1920, 1920, 16};
__attribute__((section(".data"))) int layer_with_weights[9] = {1, 0, 1, 1, 1, 1, 1, 1, 1};

#ifdef VERBOSE
// check for input/output acitvation checksum
static void check_layer(char *output, int check_sum_true, int dim) {
  int checksum = 0;
  float *ptr = (float *) output;
  for(int j=0; j<dim; j++) {
    checksum += ptr[j];
  }

  if(check_sum_true == checksum)
    printf("Checksum in/out Layer :\tOk\n");
  else 
    printf("Checksum in/out Layer :\tFailed [%u vs. %u]\n", checksum, check_sum_true);
}

#endif 


uint32_t L2_weights, L2_output, L2_input_add, L2_input;
__attribute__((section(".data"))) float L2_output_mem[1000000];
__attribute__((section(".data"))) float L2_input_add_mem[1000000];
__attribute__((section(".data"))) float L2_input_mem[1000000];
void network_run()
{   

/* 
  - initial buffer allocation L2 and L1
  - variable declaration
*/
/* ---------------------------------- */
/* -------- SECTION 0 BEGIN --------- */
/* ---------------------------------- */
  uint16_t out_mult = 0;
  uint16_t out_shift = 0;
  uint16_t inmul1 = 0;
  uint16_t inmul2 = 0;
#ifdef VERBOSE
  if (snrt_cluster_compute_core_idx()==0)
    printf("I'm Core 0 from Occamy Cluster. Beginning the neural network computation\n");
#endif
/* ---------------------------------- */
/* --------- SECTION 0 END ---------- */ 
/* ---------------------------------- */ 

  // perf measurement begin
  int cycle_network_execution = 0;
/* MAIN SECTION
  - for loop over all the layers of the network
  - double buffering using L3
  - check on layers to be executed from L3
  - residual check at the end of each layer
*/
/* ---------------------------------- */
/* -------- SECTION 2 BEGIN --------- */
/* ---------------------------------- */
  int j = 0;
  for(int i = 0; i < 9; i++)
  {
    if (layer_with_weights[i] == 1)
    {
      L2_weights = (uint32_t) Weights_tensors[j];
      j++;
    }
    if (i == 0)
    {
      L2_input = input;
      L2_output = L2_output_mem;
    }
    else if ( i % 2 == 0)
    {
      L2_input = L2_input_mem;
      L2_output = L2_output_mem;
    }
    else
    {
      L2_input = L2_output_mem;
      L2_output = L2_input_mem;
    }
#ifdef VERBOSE
    if(snrt_cluster_compute_core_idx() == 0 && snrt_cluster_idx() == 0)
    {
      if (i==0)
        check_layer(L2_input, check_activations[i], check_activations_dimension[i]);
      else if (branch_change[i-1]==0)
        check_layer(L2_input, check_activations[i], check_activations_dimension[i]);
      else
        printf("Switching branch, already checked activation\n");
    }
#endif  
    snrt_global_barrier();
    layer_i.L2_input = L2_input;
    layer_i.L2_input_add = L2_input_add;
    layer_i.L2_output = L2_output;
    layer_i.L2_weights = L2_weights;
    layer_i.l2_zeros = l2_zeros;
    layer_i.out_mult = out_mult_vector[i];
    layer_i.out_shift = out_shift_vector[i];
    layer_i.inmul1 = inmul1_vector[i];
    layer_i.inmul2 = inmul2_vector[i];
    switch (i)
    {
      case 0:
        layerConvBNRelu0(&layer_i);
        break;
      case 1:
        layerMaxPool1(&layer_i);
        break;
      case 2:
        layerConvBNRelu2(&layer_i);
        break;
      case 3:
        layerConvBNRelu3(&layer_i);
        break;
      case 4:
        layerConvBNRelu4(&layer_i);
        break;
      case 5:
        layerConvBNRelu5(&layer_i);
        break;
      case 6:
        layerConvBNRelu6(&layer_i);
        break;
      case 7:
        layerConvBNRelu7(&layer_i);
        break;
      case 8:
        layerGemm8_last(&layer_i);
        break;
    }
    snrt_global_barrier();

#ifdef VERBOSE
    if(snrt_cluster_compute_core_idx() == 0 && snrt_cluster_idx() == 0)
    {
      printf("Layer %s %d ended: \n", Layers_name[i], i);
      check_layer(L2_output, check_activations_out[i], check_activations_out_dimension[i]);
      
      if (i==100)
      {    
        check_layer_plus(L2_output,check_activations_out_dimension[i]);
      }
    }    
    snrt_global_barrier();
#endif 

  }
/* ---------------------------------- */
/* --------- SECTION 2 END ---------- */
/* ---------------------------------- */

/* ---------------------------------- */
/* -------- SECTION 3 BEGIN --------- */
/* ---------------------------------- */
  int cid = snrt_cluster_compute_core_idx();    
  int MACs = 14138880;
  if (cid == 0)
  {
    printf("[%d] : Total MACs: %d\n",cid,MACs ); 
  }
/* ---------------------------------- */
/* --------- SECTION 3 END ---------- */
/* ---------------------------------- */
}

