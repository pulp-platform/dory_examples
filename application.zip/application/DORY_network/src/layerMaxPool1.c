/*
 * layer_template.c
 * Alessio Burrello <alessio.burrello@unibo.it>
 * Francesco Conti <f.conti@unibo.it>
 *
 * Copyright (C) 2018-2020 University of Bologna
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

#include "layerMaxPool1.h"

#define VERBOSE_PRINT(...) printf(__VA_ARGS__)


void layerMaxPool1(layer* layer_i) 
{
  unsigned int l2_x =         layer_i->L2_input;
  unsigned int l2_x_2 =       layer_i->L2_input_add;
  unsigned int l2_y =         layer_i->L2_output;
  unsigned int l2_W =         layer_i->L2_weights;
  unsigned int l2_zeros =     layer_i->l2_zeros;
  unsigned int out_mult_in =  layer_i->out_mult;
  unsigned int inmul1 =       layer_i->inmul1;
  unsigned int inmul2 =       layer_i->inmul2;
  unsigned int out_shift_in = layer_i->out_shift;

  volatile kernel kernel_i;
  /// allocation of Occamy
  float *memory_cluster = (float *)snrt_cluster_memory().start;
  unsigned int l1_buffer = (unsigned int) memory_cluster;
  volatile DMA_copy DMA_copy_x, DMA_copy_y;
  DMA_copy_x.hwc_to_chw = 0;
  DMA_copy_x.stride_2d = 10240;
  DMA_copy_x.stride_1d = 128;
  DMA_copy_x.dir = 1;
  DMA_copy_x.dma_channel = NULL;
  
  DMA_copy_y.hwc_to_chw = 0;
  DMA_copy_y.stride_2d = 5120;
  DMA_copy_y.stride_1d = 128;
  DMA_copy_y.dir = 0;
  DMA_copy_y.dma_channel = NULL;

  volatile int p_r, p_l, p_t, p_b;
  volatile  unsigned short x_tile_size_nif;
  volatile unsigned short  x_tile_size_h;
  volatile unsigned short  x_tile_size_w;
  volatile unsigned short  x_tile_size_byte;
  volatile unsigned short  x_length_nif_byte;
  volatile int pad_offset_h, pad_offset_w;
  volatile unsigned short  W_tile_size_nof;
  volatile unsigned short  W_tile_size_nif;
  volatile unsigned short  W_tile_size_byte;
  volatile unsigned short W_length_nif_byte;
  volatile float *x, *W, *y, *b;
  volatile int x_tile_size_nif_exec;
  volatile int x_tile_size_h_exec;
  volatile int x_tile_size_w_exec;
  volatile int y_tile_size_nof;
  volatile int y_tile_size_h;
  volatile int y_tile_size_w;
  volatile int y_tile_size_byte;
  volatile int y_length_nof_byte;
  volatile int db_x;
  volatile int db_W;
  volatile int db_act;
  volatile int db_y;
  volatile int exec_db_x;
  volatile int exec_db_W;
  volatile int exec_db_act;
  // double buffering state
  int db_state_x=0;
  int db_state_y=1;
  // last-tile flags
  int iter;
  // tile loop indeces
  int _i_nof_load=0, _i_nif_load=0, _i_h_load=0, _i_w_load=0;
  int _i_nof_exec=0, _i_nif_exec=0, _i_h_exec=0, _i_w_exec=0;


  DMA_copy_x.ext = l2_x;
  DMA_copy_x.loc = l1_buffer + (0 + 0);
  DMA_copy_x.number_of_2d_copies = 10;
  DMA_copy_x.number_of_1d_copies = 34;
  DMA_copy_x.length_1d_copy = 116;
  DMA_copy_x.stride_L1_1d = DMA_copy_x.length_1d_copy;
  DMA_copy_x.stride_L1_2d = DMA_copy_x.length_1d_copy*DMA_copy_x.number_of_1d_copies;
  dory_dma_memcpy_async(DMA_copy_x);
  dory_dma_barrier(DMA_copy_x);


  float sum = 0;
  int total_tiles = 30;
  // tile loop nest
  for(iter=0; iter < total_tiles; iter++) {
      _i_w_load += 1;
      if(_i_w_load==3) 
      {
        _i_w_load = 0;
        _i_h_load += 1;
        if(_i_h_load==5) 
        {
          _i_h_load = 0;
          _i_nif_load += 1;
          _i_nof_load += 1;
        }
      }
    // check if last in any dimension

    // compute double buffering offsets and update db state
    db_x = !db_state_x ? 39456 : 0;
    db_y = !db_state_y ? 9864 : 0;
    exec_db_x = db_state_x ? 39456 : 0;
    db_state_x = ! db_state_x;
    //switch all double buffering offset and y only after that all n_input_features have been analyzed: we need to pass all n_in to produce a single fil
///////// POSSIBLE BUG FIX!!!!! DB_STATE_Y NOT SWITCHED /////////////

    // double buffered reads

    if(iter < (total_tiles-1) )
    {
      asm volatile("": : :"memory");
      x_tile_size_nif = (_i_nif_load+1 == 2) ? 3 : 29;
      x_tile_size_h   = (_i_h_load+1 == 5)   ? 8 : 10;
      x_tile_size_w   = (_i_w_load+1 == 3)   ? 12 : 34;
      x_tile_size_byte = x_tile_size_nif*x_tile_size_h*x_tile_size_w*32/8;
      x_length_nif_byte = (_i_nif_load+1 == 2)   ? 12 : 116;
      // additionally overlap by padding for the first tile after a border one
      //this because in the first tile we use less pixels from x_buffer, since we have the ones of padding
      pad_offset_h=0, pad_offset_w=0;
      if(_i_h_load > 0)
        pad_offset_h = 0;
      if(_i_w_load > 0)
        pad_offset_w = 0;
      y_tile_size_h   = (_i_h_load+1 == 5)   ? 4 : 5;
      y_tile_size_w   = (_i_w_load+1 == 3)   ? 6 : 17;
      // transfer of next input tile in double buffering

      DMA_copy_x.ext = dory_get_tile_3d(l2_x, _i_h_load, _i_w_load, _i_nif_load, 10, 34, 29, 80, 32,  0, 0,0, pad_offset_h, pad_offset_w, 0, 32);
      DMA_copy_x.loc = l1_buffer + (0 + db_x);
      DMA_copy_x.number_of_2d_copies = x_tile_size_h;
      DMA_copy_x.number_of_1d_copies = x_tile_size_w;
      DMA_copy_x.length_1d_copy = x_length_nif_byte;
      DMA_copy_x.stride_L1_1d = DMA_copy_x.length_1d_copy;
      DMA_copy_x.stride_L1_2d = DMA_copy_x.length_1d_copy*DMA_copy_x.number_of_1d_copies;
      dory_dma_memcpy_async(DMA_copy_x);
    }
    // creation of the pointers to input, output, weights, lambda and k

    kernel_i.pInBuffer = (float *) (l1_buffer + (0 + exec_db_x));
    kernel_i.pOutBuffer = (float *) (l1_buffer + (78904 + db_y));
    // parameter passed to the kernel. Input and output sizes
    kernel_i.ch_in = (_i_nif_exec+1 == 2) ? 3 : 29;
    kernel_i.dim_in_y   = (_i_h_exec+1 == 5)   ? 8 : 10;
    kernel_i.dim_in_x   = (_i_w_exec+1 == 3)   ? 12 : 34;
    kernel_i.ch_out = (_i_nof_exec+1 == 2) ? 3 : 29;
    kernel_i.dim_out_y   = (_i_h_exec+1 == 5)   ? 4 : 5;
    kernel_i.dim_out_x   = (_i_w_exec+1 == 3)   ? 6 : 17;
    kernel_i.stride_x = 2;
    kernel_i.stride_y = 2;
    kernel_i.dim_kernel_x = 2;
    kernel_i.dim_kernel_y = 2;
    kernel_i.padding_y_top = (_i_h_exec == 0) ? 0 : 0;
    kernel_i.padding_y_bottom = (_i_h_exec == 5-1) ? 0 : 0;
    kernel_i.padding_x_left = (_i_w_exec == 0) ? 0 : 0;
    kernel_i.padding_x_right = (_i_w_exec == 3-1) ? 0 : 0;
    y_tile_size_byte = y_tile_size_nof*y_tile_size_h*y_tile_size_w*32/8;
    y_length_nof_byte = (_i_nof_exec+1 == 2)   ? 12 : 116;


  // printf("x: ");
  // sum=0;
  // for (int i = 0; i < (x_tile_size_nif_exec*x_tile_size_h_exec*x_tile_size_w_exec); i++)
  //   sum+=*(x+i);
  // printf("%f ", sum);
  // printf("\n");


    //printf("Tile execution %d of layerMaxPool1\n", iter);
    
    occamy_pool_naive(&kernel_i);


  // printf("y: ");
  // sum=0;
  // for (int i = 0; i < (y_tile_size_nof*y_tile_size_h*y_tile_size_w); i++)
  //   sum+=*(y+i);
  // printf("%f ", sum);
  // printf("\n");
    

    // wait for DMA write/read
      dory_dma_barrier(DMA_copy_y);
      dory_dma_barrier(DMA_copy_x);
     
      DMA_copy_y.ext = dory_get_tile_3d(l2_y, _i_h_exec, _i_w_exec, _i_nof_exec, 5, 17, 29, 40, 32, 0, 0, 0, 0, 0, 0, 32);
      DMA_copy_y.loc = l1_buffer + (78904 + db_y);
      DMA_copy_y.number_of_2d_copies = (_i_h_exec+1 == 5)   ? 4 : 5;
      DMA_copy_y.number_of_1d_copies = (_i_w_exec+1 == 3)   ? 6 : 17;
      DMA_copy_y.length_1d_copy = y_length_nof_byte;
      dory_dma_memcpy_async(DMA_copy_y);  
    // update prev iterators
    db_state_y = ! db_state_y; 
    _i_nof_exec = _i_nof_load;
    _i_nif_exec = _i_nif_load;
    _i_h_exec = _i_h_load;
    _i_w_exec = _i_w_load;
  }

  // wait for final write
  dory_dma_barrier(DMA_copy_y);
}
